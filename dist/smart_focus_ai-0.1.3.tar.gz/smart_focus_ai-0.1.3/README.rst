[metadata]
name = smart_focus_ai
version = 0.1.3            
author = GeeksterLab
author_email = GeeksterLab@outlook.com

# courte description, une seule ligne
description = Détection de focus en temps réel via webcam

# longue description dans le README.rst
long_description = file: README.rst
long_description_content_type = text/x-rst

url = https://github.com/GeeksterLab/SmartFocusAI
classifiers =
    Programming Language :: Python :: 3
    License :: OSI Approved :: MIT License
    Operating System :: OS Independent

[options]
packages = find:
python_requires = >=3.10
